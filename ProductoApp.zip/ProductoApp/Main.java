package ProductoApp;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static class Producto {
        private int id;
        private String nombre;
        private double precio;
        private int cantidad;

        public Producto(int id, String nombre, double precio, int cantidad) {
            this.id = id;
            this.nombre = nombre;
            this.precio = precio;
            this.cantidad = cantidad;
        }

        public int getId() { return id; }
        public String getNombre() { return nombre; }
        public double getPrecio() { return precio; }
        public int getCantidad() { return cantidad; }

        public void setId(int id) { this.id = id; }
        public void setNombre(String nombre) { this.nombre = nombre; }
        public void setPrecio(double precio) { this.precio = precio; }
        public void setCantidad(int cantidad) { this.cantidad = cantidad; }
    }

    public static class DatabaseConnection {
        private static final String URL = "jdbc:mysql://localhost:3306/tienda";
        private static final String USER = "root";
        private static final String PASSWORD = "toki111";

        public static Connection getConnection() throws SQLException {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        }
    }

    public static class ProductoDAO {

        public void ingresarProducto(Producto producto) {
            String sql = "INSERT INTO productos (nombre, precio, cantidad) VALUES (?, ?, ?)";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, producto.getNombre());
                stmt.setDouble(2, producto.getPrecio());
                stmt.setInt(3, producto.getCantidad());
                stmt.executeUpdate();
                System.out.println("Producto ingresado correctamente.");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        public List<Producto> mostrarProductos() {
            List<Producto> productos = new ArrayList<>();
            String sql = "SELECT * FROM productos";
            try (Connection conn = DatabaseConnection.getConnection();
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    Producto producto = new Producto(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getDouble("precio"),
                        rs.getInt("cantidad")
                    );
                    productos.add(producto);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return productos;
        }

        public Producto buscarProducto(int id) {
            String sql = "SELECT * FROM productos WHERE id = ?";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, id);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    return new Producto(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getDouble("precio"),
                        rs.getInt("cantidad")
                    );
                } else {
                    System.out.println("Producto no encontrado.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return null;
        }

        public void modificarProducto(Producto producto) {
            String sql = "UPDATE productos SET nombre = ?, precio = ?, cantidad = ? WHERE id = ?";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, producto.getNombre());
                stmt.setDouble(2, producto.getPrecio());
                stmt.setInt(3, producto.getCantidad());
                stmt.setInt(4, producto.getId());
                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Producto modificado correctamente.");
                } else {
                    System.out.println("No se encontró el producto para modificar.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        public void eliminarProducto(int id) {
            String sql = "DELETE FROM productos WHERE id = ?";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, id);
                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Producto eliminado correctamente.");
                } else {
                    System.out.println("No se encontró el producto para eliminar.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        ProductoDAO productoDAO = new ProductoDAO();
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n--- Menú Principal ---");
            System.out.println("1. Ingresar producto");
            System.out.println("2. Mostrar productos");
            System.out.println("3. Buscar producto");
            System.out.println("4. Modificar producto");
            System.out.println("5. Eliminar producto");
            System.out.println("6. Salir");
            System.out.print("Elige una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();  

            switch (opcion) {
                case 1:

                    System.out.print("Nombre del producto: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Precio del producto: ");
                    double precio = scanner.nextDouble();
                    System.out.print("Cantidad del producto: ");
                    int cantidad = scanner.nextInt();
                    Producto nuevoProducto = new Producto(0, nombre, precio, cantidad);
                    productoDAO.ingresarProducto(nuevoProducto);
                    break;
                case 2:
                  
                    List<Producto> productos = productoDAO.mostrarProductos();
                    for (Producto producto : productos) {
                        System.out.println("ID: " + producto.getId() + ", Nombre: " + producto.getNombre() +
                                ", Precio: " + producto.getPrecio() + ", Cantidad: " + producto.getCantidad());
                    }
                    break;
                case 3:

                    System.out.print("ID del producto a buscar: ");
                    int idBuscar = scanner.nextInt();
                    Producto productoEncontrado = productoDAO.buscarProducto(idBuscar);
                    if (productoEncontrado != null) {
                        System.out.println("ID: " + productoEncontrado.getId() + ", Nombre: " + productoEncontrado.getNombre() +
                                ", Precio: " + productoEncontrado.getPrecio() + ", Cantidad: " + productoEncontrado.getCantidad());
                    }
                    break;
                case 4:
              
                    System.out.print("ID del producto a modificar: ");
                    int idModificar = scanner.nextInt();
                    scanner.nextLine(); // Limpiar buffer
                    Producto productoMod = productoDAO.buscarProducto(idModificar);
                    if (productoMod != null) {
                        System.out.print("Nuevo nombre: ");
                        String nuevoNombre = scanner.nextLine();
                        System.out.print("Nuevo precio: ");
                        double nuevoPrecio = scanner.nextDouble();
                        System.out.print("Nueva cantidad: ");
                        int nuevaCantidad = scanner.nextInt();
                        productoMod.setNombre(nuevoNombre);
                        productoMod.setPrecio(nuevoPrecio);
                        productoMod.setCantidad(nuevaCantidad);
                        productoDAO.modificarProducto(productoMod);
                    }
                    break;
                case 5:
                
                    System.out.print("ID del producto a eliminar: ");
                    int idEliminar = scanner.nextInt();
                    productoDAO.eliminarProducto(idEliminar);
                    break;
                case 6:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción no válida.");
                    break;
            }
        } while (opcion != 6);

        scanner.close();
    }
}
